package arroyo1and2;
//Chrystal Arroyo ID:2396581
//set up your output for the math equation
//compute the equation 

public class SolveProblem {
	public static void main(String[] args) {
		//output for math equation using print
		System.out.print("(12.5 + 5.5 / 3) / (6.25 * 6 - 5.0) = " );
		//compute the equation and use println
		System.out.println((12.5 + 5.5 / 3) / (6.25 * 6 - 5.0));
	}
}
