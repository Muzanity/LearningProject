package arroyo1and2;
// Chrystal Arroyo ID:2396581
//set up the print line for my name
//set up the print line for the creator of java
//create the java rocks print line

public class Introduction {
	public static void main(String[]args) {
		//println for name
		System.out.println("Chrystal Arroyo");
		//println for creator
		System.out.println("James Gosling");
		//println for java rocks
		System.out.println("Java rocks!");
	}
}
